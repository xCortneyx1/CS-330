///////////////////////////////////////////////////////////////////////////////
// maincode.cpp
// ============
// gets called when application is launched - initializes GLEW, GLFW
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include <iostream>         // error handling and output
#include <cstdlib>          // EXIT_FAILURE

#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
    // Macro for window title
    const char* const WINDOW_TITLE = "7-1 FinalProject and Milestones";

    // Main GLFW window
    GLFWwindow* g_Window = nullptr;

    // scene manager object for managing the 3D scene prepare and render
    SceneManager* g_SceneManager = nullptr;
    // shader manager object for dynamic interaction with the shader code
    ShaderManager* g_ShaderManager = nullptr;
    // view manager object for managing the 3D view setup and projection to 2D
    ViewManager* g_ViewManager = nullptr;
}

// Function declarations - all functions that are called manually
// need to be pre-declared at the beginning of the source code.
bool InitializeGLFW();
bool InitializeGLEW();


/***********************************************************
 *  main(int, char*)
 *
 *  This function gets called after the application has been
 *  launched.
 ***********************************************************/
int main(int argc, char* argv[])
{
    // if GLFW fails initialization, then terminate the application
    if (InitializeGLFW() == false)
    {
        return(EXIT_FAILURE);
    }

    // try to create a new shader manager object
    g_ShaderManager = new ShaderManager();
    // try to create a new view manager object
    g_ViewManager = new ViewManager(
        g_ShaderManager);

    // try to create the main display window
    g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
    if (!g_Window) { return EXIT_FAILURE; } // guard just in case

    // if GLEW fails initialization, then terminate the application
    if (InitializeGLEW() == false)
    {
        return(EXIT_FAILURE);
    }

    // set initial viewport to the actual framebuffer size (first frame)
    {
        int fbw = 0, fbh = 0;
        glfwGetFramebufferSize(g_Window, &fbw, &fbh);
        if (fbw < 1) fbw = 1;
        if (fbh < 1) fbh = 1;
        glViewport(0, 0, fbw, fbh);
    }
    glfwSwapInterval(1); // vsync

    // load the shader code from the external GLSL files
    g_ShaderManager->LoadShaders(
        "shaders/vertexShader.glsl",
        "shaders/fragmentShader.glsl");
    g_ShaderManager->use();

    // --- GL state that should be set once ---
    glEnable(GL_DEPTH_TEST);                          // Enable z-depth once, not every frame
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(0.93f, 0.95f, 1.0f, 1.0f);           // soft background

    // --- Set safe default uniforms your fragment shader expects ---
    g_ShaderManager->setIntValue("bUseLighting", 0);
    g_ShaderManager->setIntValue("bUseTexture", 0);
    g_ShaderManager->setVec2Value("UVscale", glm::vec2(1.0f, 1.0f));
    g_ShaderManager->setVec3Value("material.diffuseColor", glm::vec3(1.0f, 1.0f, 1.0f));
    g_ShaderManager->setVec3Value("material.specularColor", glm::vec3(1.0f, 1.0f, 1.0f));
    g_ShaderManager->setFloatValue("material.shininess", 32.0f);
    g_ShaderManager->setIntValue("directionalLight.bActive", 0);
    for (int i = 0; i < 5; ++i)
    {
        std::string tag = "pointLights[" + std::to_string(i) + "].bActive";
        g_ShaderManager->setIntValue(tag.c_str(), 0);
    }
    g_ShaderManager->setIntValue("spotLight.bActive", 0);

    // try to create a new scene manager object and prepare the 3D scene
    g_SceneManager = new SceneManager(g_ShaderManager);
    g_SceneManager->PrepareScene();

    // loop will keep running until the application is closed 
    // or until an error has occurred
    while (!glfwWindowShouldClose(g_Window))
    {
        // Clear the frame and z buffers
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // convert from 3D object space to 2D view
        g_ViewManager->PrepareSceneView();

        // refresh the 3D scene
        g_ShaderManager->use();           // make sure program is active before drawing
        g_SceneManager->RenderScene();

        // Flips the the back buffer with the front buffer every frame.
        glfwSwapBuffers(g_Window);

        // query the latest GLFW events
        glfwPollEvents();

        // minimal GL error check (helps catch silent faults)
        GLenum err = glGetError();
        if (err != GL_NO_ERROR) {
            std::cerr << "OpenGL error: 0x" << std::hex << err << std::dec << "\n";
        }
    }

    // clear the allocated manager objects from memory
    if (NULL != g_SceneManager)
    {
        delete g_SceneManager;
        g_SceneManager = NULL;
    }
    if (NULL != g_ViewManager)
    {
        delete g_ViewManager;
        g_ViewManager = NULL;
    }
    if (NULL != g_ShaderManager)
    {
        delete g_ShaderManager;
        g_ShaderManager = NULL;
    }

    // Terminates the program successfully
    exit(EXIT_SUCCESS);
}

/***********************************************************
 *  InitializeGLFW()
 *
 *  This function is used to initialize the GLFW library.
 ***********************************************************/
bool InitializeGLFW()
{
    // GLFW: initialize and configure library
    // --------------------------------------
    glfwInit();

#ifdef __APPLE__
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
    // set the version of OpenGL and profile to use
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif
    // GLFW: end -------------------------------

    return(true);
}

/***********************************************************
 *  InitializeGLEW()
 *
 *  This function is used to initialize the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
    // GLEW: initialize
    // -----------------------------------------
    GLenum GLEWInitResult = GLEW_OK;

    // **core profile note** � load modern entry points
    glewExperimental = GL_TRUE; // prevents access violations on some drivers

    // try to initialize the GLEW library
    GLEWInitResult = glewInit();
    if (GLEW_OK != GLEWInitResult)
    {
        std::cerr << glewGetErrorString(GLEWInitResult) << std::endl;
        return false;
    }
    // GLEW: end -------------------------------

    // Displays a successful OpenGL initialization message
    std::cout << "INFO: OpenGL Successfully Initialized\n";
    std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << "\n" << std::endl;

    return(true);
}

﻿///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"
#include "ShaderManager.h"
#include "ShapeMeshes.h"

// OpenGL headers
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>
#include <iostream>

// uniforms used by the shaders
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    m_loadedTextures = 0;
    for (int i = 0; i < 16; ++i)
    {
        m_textureIDs[i].tag = "";
        m_textureIDs[i].ID = 0;
    }
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    DestroyGLTextures();
    m_pShaderManager = NULL;
    delete m_basicMeshes;
    m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    if (m_loadedTextures >= 16)
    {
        std::cout << "Warning: texture slot limit reached (16).\n";
        return false;
    }

    int width = 0, height = 0, channels = 0;
    stbi_set_flip_vertically_on_load(true);

    unsigned char* pixels = stbi_load(filename, &width, &height, &channels, 0);
    if (!pixels)
    {
        std::cout << "Could not load image:" << filename << std::endl;
        return false;
    }

    std::cout << "Loaded image: " << filename << " (" << width << "x" << height << ", ch=" << channels << ")\n";

    GLuint texID = 0;
    glGenTextures(1, &texID);
    glBindTexture(GL_TEXTURE_2D, texID);

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    GLenum format = (channels == 4) ? GL_RGBA : GL_RGB;
    GLint  internal = (channels == 4) ? GL_RGBA8 : GL_RGB8;

    // ---- FIX: ensure safe row alignment for 3-channel images ----
    GLint prevUnpackAlign = 0;
    glGetIntegerv(GL_UNPACK_ALIGNMENT, &prevUnpackAlign);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    // -------------------------------------------------------------

    glTexImage2D(GL_TEXTURE_2D, 0, internal, width, height, 0, format, GL_UNSIGNED_BYTE, pixels);
    glGenerateMipmap(GL_TEXTURE_2D);

    // ---- restore previous unpack alignment -------
    glPixelStorei(GL_UNPACK_ALIGNMENT, prevUnpackAlign);
    // -------------------------------------------------------------

    glBindTexture(GL_TEXTURE_2D, 0);
    stbi_image_free(pixels);

    m_textureIDs[m_loadedTextures].tag = tag;
    m_textureIDs[m_loadedTextures].ID = static_cast<uint32_t>(texID);
    ++m_loadedTextures;

    return true;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, static_cast<GLuint>(m_textureIDs[i].ID));
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; ++i)
    {
        if (m_textureIDs[i].ID != 0)
        {
            GLuint id = static_cast<GLuint>(m_textureIDs[i].ID);
            glDeleteTextures(1, &id);
            m_textureIDs[i].ID = 0;
        }
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
        if (m_textureIDs[i].tag == tag) return static_cast<int>(m_textureIDs[i].ID);
    return -1;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; ++i)
        if (m_textureIDs[i].tag == tag) return i;
    return -1;
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager)
        m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    const int    slot = FindTextureSlot(textureTag);
    const GLuint id = (slot >= 0) ? static_cast<GLuint>(FindTextureID(textureTag)) : 0;

    if (slot < 0 || id == 0)
    {
        if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, 0);
        return;
    }

    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseTextureName, 1);

    glActiveTexture(GL_TEXTURE0 + slot);
    glBindTexture(GL_TEXTURE_2D, id);

    if (m_pShaderManager) m_pShaderManager->setIntValue(g_TextureValueName, slot);
    SetTextureUVScale(1.0f, 1.0f);
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ)
{
    glm::mat4 modelView;
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
    glm::mat4 translation = glm::translate(positionXYZ);

    modelView = translation * rotationZ * rotationY * rotationX * scale;

    if (m_pShaderManager)
        m_pShaderManager->setMat4Value(g_ModelName, modelView);
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    glm::vec4 currentColor(r, g, b, a);
    if (m_pShaderManager)
    {
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
    }
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    for (const auto& m : m_objectMaterials)
    {
        if (m.tag == tag) { material = m; return true; }
    }
    return false;
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string /*materialTag*/)
{
    if (m_pShaderManager) m_pShaderManager->setIntValue(g_UseLightingName, 0);
}

/*** helpers ***/
inline void EnableLighting(bool enabled, ShaderManager* sm)
{
    if (sm) sm->setBoolValue(g_UseLightingName, enabled ? 1 : 0);
}

inline void SetMaterial(ShaderManager* sm, const glm::vec3& kd, const glm::vec3& ks, float shininess)
{
    if (!sm) return;
    sm->setVec3Value("material.diffuseColor", kd);
    sm->setVec3Value("material.specularColor", ks);
    sm->setFloatValue("material.shininess", shininess);
}

/*** Lights ***/
void SceneManager::SetupSceneLights()
{
    EnableLighting(true, m_pShaderManager);

    // Directional key (soft warm)
    m_pShaderManager->setVec3Value("directionalLight.direction", -0.35f, -1.0f, -0.25f);
    m_pShaderManager->setVec3Value("directionalLight.ambient", 0.06f, 0.06f, 0.06f);
    m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.90f, 0.82f, 0.70f);
    m_pShaderManager->setVec3Value("directionalLight.specular", 1.00f, 0.95f, 0.90f);
    m_pShaderManager->setBoolValue("directionalLight.bActive", true);

    // Cool point fill
    m_pShaderManager->setVec3Value("pointLights[0].position", 0.0f, 2.2f, 1.2f);
    m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.02f, 0.03f, 0.05f);
    m_pShaderManager->setVec3Value("pointLights[0].diffuse", 0.30f, 0.40f, 0.60f);
    m_pShaderManager->setVec3Value("pointLights[0].specular", 0.30f, 0.40f, 0.60f);
    m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

    // deactivate the rest
    for (int i = 1; i < 5; ++i)
        m_pShaderManager->setBoolValue(("pointLights[" + std::to_string(i) + "].bActive").c_str(), false);

    // no spotlight in this scene
    m_pShaderManager->setBoolValue("spotLight.bActive", false);
}

/***********************************************************
 *  LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    CreateGLTexture("textures/floor_tiles.jpg", "tex_floor");
    CreateGLTexture("textures/wood.jpg", "tex_wood");
    CreateGLTexture("textures/marble.png", "tex_marble");
    CreateGLTexture("textures/metal.png", "tex_metal");
    CreateGLTexture("textures/mosaic.jpg", "tex_mosaic");
    CreateGLTexture("textures/brick.jpg", "tex_brick");

    BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    LoadSceneTextures();
    SetupSceneLights();

    // One instance per mesh type
    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadSphereMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadTaperedCylinderMesh();
    m_basicMeshes->LoadConeMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    float XrotationDegrees = 0.0f;
    float YrotationDegrees = 0.0f;
    float ZrotationDegrees = 0.0f;
    glm::vec3 positionXYZ;

    /********************* BACK WALL (unlit) *********************/
    scaleXYZ = glm::vec3(20.0f, 0.10f, 10.0f);
    XrotationDegrees = 90.0f;
    positionXYZ = glm::vec3(0.0f, 8.2f, -9.0f);
    SetTransformations(scaleXYZ, XrotationDegrees, 0.0f, 0.0f, positionXYZ);

    EnableLighting(false, m_pShaderManager);
    SetShaderColor(0.96f, 0.96f, 0.98f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    /*********************** FLOOR (lit, textured) ***********************/
    scaleXYZ = glm::vec3(18.0f, 0.10f, 10.0f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, glm::vec3(0.0f));

    EnableLighting(true, m_pShaderManager);
    SetMaterial(m_pShaderManager,
        glm::vec3(0.90f, 0.85f, 0.75f),
        glm::vec3(0.50f, 0.45f, 0.35f),
        24.0f);
    SetShaderTexture("tex_floor");
    SetTextureUVScale(6.0f, 6.0f);
    m_basicMeshes->DrawPlaneMesh();

    /*********************** TOP MAT (flat color, unlit) ***********************/
    EnableLighting(false, m_pShaderManager);
    scaleXYZ = glm::vec3(10.0f, 0.05f, 4.2f);
    positionXYZ = glm::vec3(0.0f, 0.06f, 0.6f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.12f, 0.45f, 0.75f, 1.0f);
    m_basicMeshes->DrawPlaneMesh();

    /*********************** FROM HERE: LIT OBJECTS ***********************/
    EnableLighting(true, m_pShaderManager);

    // -------- Rolled mat (cylinder) — textured, matte
    scaleXYZ = glm::vec3(3.00f, 0.55f, 0.55f);
    positionXYZ = glm::vec3(-0.50f, 0.90f, -0.90f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 180.0f, positionXYZ);

    SetMaterial(m_pShaderManager, glm::vec3(1.0f), glm::vec3(0.15f), 16.0f);
    SetShaderTexture("tex_wood");
    SetTextureUVScale(4.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // -------- Kettlebell (sphere + torus) — shiny
    SetMaterial(m_pShaderManager, glm::vec3(1.0f), glm::vec3(0.85f), 96.0f);

    // bell
    scaleXYZ = glm::vec3(1.05f, 0.95f, 1.05f);
    positionXYZ = glm::vec3(-2.00f, 0.95f, 0.56f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderTexture("tex_marble");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawSphereMesh();

    // handle
    scaleXYZ = glm::vec3(1.10f, 0.35f, 0.88f);
    positionXYZ = glm::vec3(-2.00f, 2.05f, 0.51f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderTexture("tex_metal");
    SetTextureUVScale(2.0f, 2.0f);
    m_basicMeshes->DrawTorusMesh();

    // -------- Water bottle (colored plastic, lit)
    SetMaterial(m_pShaderManager, glm::vec3(1.0f), glm::vec3(0.35f), 48.0f);

    // body
    scaleXYZ = glm::vec3(0.48f, 1.65f, 0.48f);
    positionXYZ = glm::vec3(0.90f, 1.02f, 1.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.55f, 0.80f, 0.95f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // neck
    scaleXYZ = glm::vec3(0.34f, 0.45f, 0.34f);
    positionXYZ = glm::vec3(0.90f, 2.62f, 1.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.65f, 0.85f, 0.98f, 1.0f);
    m_basicMeshes->DrawTaperedCylinderMesh();

    // cap
    scaleXYZ = glm::vec3(0.28f, 0.26f, 0.28f);
    positionXYZ = glm::vec3(0.90f, 3.05f, 1.5f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderColor(0.35f, 0.60f, 0.80f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // -------- Yoga block (textured foam, matte)
    SetMaterial(m_pShaderManager, glm::vec3(1.0f), glm::vec3(0.10f), 12.0f);
    scaleXYZ = glm::vec3(1.05f, 1.60f, 0.80f);
    positionXYZ = glm::vec3(2.05f, 1.00f, 0.62f);
    SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
    SetShaderTexture("tex_mosaic");
    SetTextureUVScale(1.5f, 1.5f);
    m_basicMeshes->DrawBoxMesh();
}

///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ==============
// Manages preparing and rendering 3D scenes, including textures, lighting,
// transformations, and materials.  Works with ShaderManager and ShapeMeshes.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University
// COURSE: CS-330 Computational Graphics and Visualization
///////////////////////////////////////////////////////////////////////////////
#pragma once

// Forward declarations
class ShaderManager;
class ShapeMeshes;

// GLM for math
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <string>
#include <vector>

///////////////////////////////////////////////////////////////////////////////
// STRUCTS
///////////////////////////////////////////////////////////////////////////////
struct OBJECT_MATERIAL
{
    std::string tag;
    glm::vec3 diffuseColor {1.0f, 1.0f, 1.0f};
    glm::vec3 specularColor{1.0f, 1.0f, 1.0f};
    float     shininess {32.0f};
};

struct TEXTURE_ID
{
    std::string tag;
    unsigned int ID {0};
};

///////////////////////////////////////////////////////////////////////////////
// CLASS
///////////////////////////////////////////////////////////////////////////////
class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    // Core
    void PrepareScene();
    void RenderScene();

    // Transformations
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ);

    // Shader color & materials
    void SetShaderColor(float r, float g, float b, float a);
    void SetShaderMaterial(std::string materialTag);
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

    // Texture management
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    int  FindTextureID(std::string tag);
    int  FindTextureSlot(std::string tag);

private:
    // Scene setup helpers
    void LoadSceneTextures();
    void SetupSceneLights();
    void DefineObjectMaterials(); // reserved for future use

private:
    ShaderManager*               m_pShaderManager {nullptr};
    ShapeMeshes*                 m_basicMeshes    {nullptr};
    std::vector<OBJECT_MATERIAL> m_objectMaterials;
    int                          m_loadedTextures {0};
    TEXTURE_ID                   m_textureIDs[16];
};

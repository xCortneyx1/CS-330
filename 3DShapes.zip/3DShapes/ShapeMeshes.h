///////////////////////////////////////////////////////////////////////////////
// shapemeshes.h
// ============
// create meshes for various 3D primitives: 
//     box, cone, cylinder, plane, prism, pyramid, sphere, tapered cylinder, torus
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 7th, 2022
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <GL/glew.h>
#include <glm/glm.hpp>
#include <vector>

class ShapeMeshes
{
public:
    ShapeMeshes();
    ~ShapeMeshes() = default;

private:
    struct GLMesh
    {
        GLuint vao = 0;        // Vertex array object
        GLuint vbos[2] = { 0, 0 };   // [0]=VBO, [1]=EBO (if used)
        GLuint nVertices = 0;        // For glDrawArrays paths
        GLuint nIndices = 0;        // For glDrawElements paths
        int    numSlices = 0;        // For cones/cylinders
    };

    // available 3D shapes
    GLMesh m_BoxMesh{};
    GLMesh m_ConeMesh{};
    GLMesh m_CylinderMesh{};
    GLMesh m_PlaneMesh{};
    GLMesh m_PrismMesh{};
    GLMesh m_Pyramid3Mesh{};
    GLMesh m_Pyramid4Mesh{};
    GLMesh m_SphereMesh{};
    GLMesh m_TaperedCylinderMesh{};
    GLMesh m_TorusMesh{};
    GLMesh m_ExtraTorusMesh1{};
    GLMesh m_ExtraTorusMesh2{};

    bool m_bMemoryLayoutDone = false;

public:
    enum BoxSide { front, back, left, right, top, bottom };

    // loaders
    void LoadBoxMesh();
    void LoadConeMesh(float radius = 1.0f, float height = 1.0f, int numSlices = 36);
    void LoadCylinderMesh(float radius = 1.0f, float height = 1.0f, int numSlices = 36);
    void LoadPlaneMesh(float width = 2.0f, float height = 2.0f);
    void LoadPrismMesh();
    void LoadPyramid3Mesh();
    void LoadPyramid4Mesh(float baseSize = 1.0f, float height = 1.0f);
    void LoadSphereMesh(int latitudeSegments = 16, int longitudeSegments = 16, float radius = 1.0f);
    void LoadTaperedCylinderMesh();
    void LoadTorusMesh(float mainRadius = 1.0f, float tubeRadius = 0.3f, int mainSegments = 30, int tubeSegments = 30);
    void LoadExtraTorusMesh1(float thickness = 0.4f);
    void LoadExtraTorusMesh2(float thickness = 0.6f);

    // filled draws
    void DrawBoxMesh() const;
    void DrawBoxMeshSide(BoxSide side) const;
    void DrawConeMesh(bool bDrawBottom = true);
    void DrawCylinderMesh(bool bDrawTop = true, bool bDrawBottom = true, bool bDrawSides = true);
    void DrawPlaneMesh();
    void DrawPrismMesh();
    void DrawPyramid3Mesh();
    void DrawPyramid4Mesh();
    void DrawSphereMesh();
    void DrawHalfSphereMesh();
    void DrawTaperedCylinderMesh(bool bDrawTop = true, bool bDrawBottom = true, bool bDrawSides = true);
    void DrawTorusMesh();
    void DrawHalfTorusMesh();

    // wireframe draws
    void DrawBoxMeshLines() const;
    void DrawConeMeshLines(bool bDrawBottom = true);
    void DrawCylinderMeshLines(bool bDrawTop = true, bool bDrawBottom = true, bool bDrawSides = true);
    void DrawPlaneMeshLines();
    void DrawPrismMeshLines();
    void DrawPyramid3MeshLines();
    void DrawPyramid4MeshLines();
    void DrawSphereMeshLines();
    void DrawHalfSphereMeshLines();
    void DrawTaperedCylinderMeshLines(bool bDrawTop = true, bool bDrawBottom = true, bool bDrawSides = true);
    void DrawTorusMeshLines();
    void DrawHalfTorusMeshLines();
    void DrawExtraTorusMesh1();
    void DrawExtraTorusMesh2();

private:
    glm::vec3 QuadCrossProduct(glm::vec3 pnt0, glm::vec3 pnt1, glm::vec3 pnt2, glm::vec3 pnt3);
    glm::vec3 CalculateTriangleNormal(glm::vec3 p0, glm::vec3 p1, glm::vec3 p2);

    void SetShaderMemoryLayout();
};
